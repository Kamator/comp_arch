#include "util.h"

int main() {
	puts("Hello, MiRiscV");
	return 0;
}
