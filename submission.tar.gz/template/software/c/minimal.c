int main() {
    putchar('V');
    putchar(10);
    return 0;
}
